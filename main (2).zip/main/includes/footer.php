 <footer class="footer">
            <div class="container">
              
                <div class="row">
                    <div class="col-md-12 text-center">
                       
                        <div class="copyright">&copy; Developed by @Tech_ties.</div>
                    </div>
                </div>
            </div><!-- end container -->
        </footer><!-- end footer -->