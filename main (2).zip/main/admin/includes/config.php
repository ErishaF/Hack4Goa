<?php
/* Database config */
$servername = "localhost";
$username = "root";
$password = "";
$db="doubledocks";
$conn = mysqli_connect($servername, $username, $password,$db);

/* End config */
?>
