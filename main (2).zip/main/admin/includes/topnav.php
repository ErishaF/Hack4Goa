<nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part">
                    <!-- Logo -->
                    <a class="logo" href="dashboard.php">
                      
                      <span style="color: #000; font-family: ALgerian; font-size: 24px;"><b>LOCAL VO!CE</b></span>
                         
                    </a>
                </div>
                <!-- /Logo -->
                
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>